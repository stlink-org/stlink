#!/bin/bash

ISOSXLION=$(sw_vers -productVersion | grep 10.7)
if [ -z $ISOSXLION ] ; then
	KEXT="stlink_shield10_6.kext"
else
	KEXT="stlink_shield10_7.kext"
fi
chown -R root:wheel osx/$KEXT/
cp -R osx/$KEXT /System/Library/Extensions/stlink_shield.kext
kextload -v /System/Library/Extensions/stlink_shield.kext
touch /System/Library/Extensions
